/* global QUnit */

sap.ui.require(["materialmaster/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
