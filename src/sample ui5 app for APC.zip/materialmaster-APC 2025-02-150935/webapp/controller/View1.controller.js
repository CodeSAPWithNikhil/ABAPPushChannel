sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/ws/WebSocket",
  "sap/m/MessageBox",
  "sap/ui/model/json/JSONModel",
  "sap/ui/core/Fragment"
],
  function (Controller, WebSocket, MessageBox, JSONModel, Fragment) {
    "use strict";

    return Controller.extend("materialmaster.controller.View1", {
      onInit: function () {
        this.createMessagesJSONModel(); //JSON Model to store messages received

        var oWebSocket = new WebSocket("/sap/bc/apc/sap/zapc_basic");

        oWebSocket.attachOpen((oEvent) => {
          MessageBox.information("WebSocket connection opened");
        });

        oWebSocket.attachMessage(function (oEvent) { // Attach an event handler for the 'message' event

          var sMessage = oEvent.getParameter("data"); // Get the sent message data 
          MessageBox.information(sMessage);

          this.storeMessage(sMessage);

        }.bind(this)
        );

        oWebSocket.attachError(function (oEvent) {
          MessageBox.information("WebSocket error occurred");
          
          this.storeMessage("Error websocket");
        }.bind(this));

        oWebSocket.attachClose((oEvent) => {
          MessageBox.information("Websocket closed")

        });

      },
      storeMessage(sMessage) {
        var sMessageLine = {};
        sMessageLine.text = sMessage;
        sMessageLine.timeStamp = new Date();
        this.oModel.getObject("/messages").push(sMessageLine);
        // this.getOwnerComponent().setModel(this.oModel, "msgModel");

      },
      showNotifications() {
        // if (!this._pDialog) {
          var that = this;
          this._pDialog = Fragment.load({
            id: this.getView().getId(),
            name: "materialmaster.view.notifications",
            controller: this
          }).then(function (oDialog){
            oDialog.setModel(that.oModel,"msgModel");
            return oDialog;
          });
        // }
        this._pDialog.then(function(oDialog){
          oDialog.open();
        }.bind(this));
        

      },
      onDialogClose() {
        this._pDialog.then(function(oDialog){
          oDialog.destroy();
        }.bind(this));
      },
      onBack() {
        window.history.go(-1);
      },
      createMessagesJSONModel() {
        this.oModel = new JSONModel();
        this.oModel.setData({ "messages": [] });
        this.getView().setModel(this.oModel, "msgModel");
      }
    });
  });
